import groovy.json.JsonSlurper
import org.formation.dynamic.CSVExporter
import org.formation.dynamic.JsonExporter
import org.formation.dynamic.XMLExporter
import org.formation.model.DBHelper
import org.formation.model.Index
import org.formation.model.IndexDAO
import org.formation.service.IndexerService


import groovy.sql.Sql

response.contentType = 'application/json'

// Access headers, with context bound variable
if (headers['Content-Type'] != "application/json") {
    throw new RuntimeException("Please use 'application/json' header")
}

