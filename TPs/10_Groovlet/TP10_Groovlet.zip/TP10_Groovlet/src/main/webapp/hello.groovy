
// output some content

out << 'Bonjour, World!'