# Info

A sample web-application using Groovlets.

## Usage

Run embedded web-server via gradle

    gradle jettyRun

and access the webapp at http://localhost:8080/groovlets-webapp-sample/

## Info

For more info explore source comments or visit the related
 [post on my blog](http://www.rolandfg.net/2014/01/06/web-apps-using-groovlets/).

